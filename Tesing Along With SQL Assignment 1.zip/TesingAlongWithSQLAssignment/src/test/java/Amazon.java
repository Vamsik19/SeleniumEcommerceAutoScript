import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Amazon {

    public WebDriver driver;

        @Given("Launch amazon application.")
        public void launch_amazon_application() {
            WebDriverManager.chromedriver().setup();

            driver=new ChromeDriver();

            driver.manage().window().maximize();

            driver.get("https://www.amazon.in/");
        }


        @And("Search for {string} book.")
        public void search_for_book(String bookName) {
            WebElement searchBox=driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]"));
            searchBox.sendKeys(bookName);
        }

        @And("Click on search button.")
        public void clickOnSearchButton() {
            WebElement searchButton= driver.findElement(By.xpath("//*[@id=\"nav-search-submit-button\"]"));
            searchButton.click();
        }

        @When("Find 3rd result of C programming book.")
        public void find_3rd_result_of_c_programming_book() {
            WebElement booksList= driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[1]/div/span[1]/div[1]/div[5]/div/div/span/div/div/div/div[2]/div/div/div[3]/div[1]/div/div[1]/div[1]/a"));
            booksList.click();
        }

        @Then("Display book Details.")
        public void display_book_details() {
            WebElement bookTitle=driver.findElement(By.xpath("//*[@id=\"productTitle\"]"));
            WebElement author = driver.findElement(By.xpath("//*[@id=\"bylineInfo\"]/span/a"));
            WebElement MRP = driver.findElement(By.xpath("//*[@id=\"corePriceDisplay_desktop_feature_div\"]/div[2]/span/span[1]/span[2]/span/span[2]"));
            WebElement price= driver.findElement(By.xpath("//*[@id=\"corePriceDisplay_desktop_feature_div\"]/div[1]/span[3]/span[2]/span[2]"));
            System.out.println("Book Details: ");
            System.out.println("The title of the Book : "+bookTitle.getText());
            System.out.println("Author Name           : "+author.getText());
            System.out.println("MRP (including taxes) : "+MRP.getText());
            System.out.println("Price (After Discount): ₹"+price.getText());

        }


}
